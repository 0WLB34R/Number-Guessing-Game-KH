import java.awt.event.*;

import javax.swing.*; 

public class Main implements ActionListener{
		private static JFrame w;
		private static JPanel p;
		private static JButton b; 
		private static JLabel l;
		private static JTextField t;
		private static int tries = 0;
		private static int rand;
	public static void main(String[] args) {
		rand = (int)(Math.random()*100);
		w = new JFrame("Guessing Game");
		p = new JPanel();
		l = new JLabel();	
		b = new JButton("Submit");
		t = new JTextField();
		
		w.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		w.setSize(450,200);
		w.setResizable(true);
		w.add(p);
		
		p.setLayout(null);

		l.setText("I'm thinking of a number between 1 and 100. Can you guess it?");
		l.setBounds(20, 20, 450, 25);
		
		t.setBounds(200,70,50,20);
		
		b.setBounds(200, 120, 50, 20);
		b.addActionListener(new Main());
		
		p.add(l);
		p.add(t);
		p.add(b);
		w.setVisible(true);
		

	}
	@Override
	public void actionPerformed(ActionEvent e) {
		String answer = t.getText();
		int numAns;
		
		try {
			numAns = Integer.parseInt(answer);
			
			if(numAns > 100 || numAns < 1) {
				l.setText("That's not in the number range I gave you!");
			}else if(numAns > rand) {
				l.setText("Too high! Try lower!");
				tries++;
			}else if(numAns < rand) {
				l.setText("Too low! Try higher!");
				tries++;
			}else if(numAns == rand) {
				l.setText("Perfect! And it only took you "+tries+" tries!");
				b.setVisible(false);
			}
		}
		
		catch (Exception E) {
			l.setText("Numbers only! Try again!");
		}
		
		
		
		
		
	}

}
